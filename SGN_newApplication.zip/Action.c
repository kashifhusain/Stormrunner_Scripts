Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_cookie("EktGUID=9dd3717a-9a5a-4633-9ed8-da417734a302; DOMAIN=www.sgn.co.uk");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=r20swj13mr.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20161220; DOMAIN=r20swj13mr.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=ieonline.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20161220; DOMAIN=ieonline.microsoft.com");

	web_add_cookie("SRCHUID=V=2&GUID=380748D552D74AC5B0F5D82ADC0410DA; DOMAIN=ieonline.microsoft.com");

	web_url("www.sgn.co.uk", 
		"URL=http://www.sgn.co.uk/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.sgn.co.uk/WebResource.axd?d=aOgP67iRH9VtGEflBarWk5DJ4Ww0rkp72uGffVwNaHaHCs5WALA-ZI1h9lwAW8WfgCR9iOc9LnTgU3EoihFp4iGlGUg1&t=635802997220000000", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/ScriptResource.axd?d=XJ91eqeOWdbvfgIM0ICGQ9czP5_d0UNrti8d4tkfF4KvhbYzpI9k3e6bKXppVHW_jVrYI1fPHUYR7pizwJJ0KaylL4-mHqV8YdWpIANNwVyC7rhqozQM8Q0p3UbCM8nutxkxbj8wsP_LwZV4B607QVcLhgCKeQ5c0fvKp3bCbrrJOMBa0&t=5f9d5645", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/ScriptResource.axd?d=K2g_57wYEFmw9E-IG-f4eUIZOpTPMhV7r26g4uROvCI4PYjHdrKhzL9O_9AiJfnrEEA7kTEzx_bHyzbITC3NNipCk4mv-_HXopCqt5Ujb8Bly6aJQIitNdUokTqgF1QQceS3GQTQPQiITA2JK4Jq55F5POMRittIafkl_iejS60wykJQ0&t=5f9d5645", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedFiles/Marketing/Controls/Rotating-Banners/CAROUSEL-170314.js", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Controls/Site_Logos/scotia_red_blue.jpg", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/1x1-transparency.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Emergency-Trio.jpg", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Connect.jpg", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Upgrade.jpg", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/270x60-Our-Latest-News.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/270x93-Button-More-SGN-News.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Vacancies.jpg", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Recognise.jpg", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/Annual-report-button.jpg", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Dead-Or-Alive.png?n=6745", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-SGN-Alert.png?n=6446", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Vulnerable-Customers.png?n=3454", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/270x60-SGN-Who-Are-We.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x60-Contact-Us.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/270x93-Button-About-Us.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x106-Customer-Service-Smell-Gas-Transparency.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x58-Twitter-Transparency.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x48-Facebook-Transparency.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/images/background.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/images/icon-sprites.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/wtid.js", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Controls/Rotating-Banners/170303-co-monster-compettion-v2.gif", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/dcs.gif?dcsredirect=126&dcstlh=0&dcstlv=0&dcsdat=1489668950905&dcssip=www.sgn.co.uk&dcsuri=/&WT.tz=0&WT.bh=12&WT.ul=en-US&WT.cd=24&WT.sr=1920x1080&WT.jo=Yes&WT.ti=SGN:%20Your%20gas.%20Our%20network.%20Home&WT.js=Yes&WT.jv=1.5&WT.ct=unknown&WT.bs=1920x929&WT.fv=Not%20enabled&WT.slv=Unknown&WT.tv=9.4.0&WT.dl=0&WT.ssl=1&WT.es=www.sgn.co.uk/&WT.vt_f_a=2&WT.vt_f=2", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://r20swj13mr.microsoft.com/ieblocklist/v1/urlblockindex.bin", "Referer=", ENDITEM, 
		"Url=https://ieonline.microsoft.com/iedomainsuggestions/ie11/suggestions.en-US", "Referer=", ENDITEM, 
		LAST);

	web_url("Our-Services", 
		"URL=https://www.sgn.co.uk/Our-Services/Our-Services/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.sgn.co.uk/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/uploadedImages/Marketing/Controls/Site_Logos/scotia_red_blue.jpg", ENDITEM, 
		"Url=/uploadedImages/Marketing/Pages/Our-Services/Our-Services-Images/connections-our-services-475px-200px.jpg?n=4929", ENDITEM, 
		"Url=/images/breadcrumb-arrow.png", ENDITEM, 
		"Url=/images/breadcrumb-arrow-end.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Pages/Our-Services/Our-Services-Images/200x338-RHS-Connect.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/1x1-transparency.png", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/wtid.js", ENDITEM, 
		"Url=/images/background.png", ENDITEM, 
		"Url=/images/menu-side-bg-arrow.png", ENDITEM, 
		"Url=/images/icon-sprites.png", ENDITEM, 
		"Url=/images/menu-side-bg.png", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/dcs.gif?&dcsdat=1489668977116&dcssip=www.sgn.co.uk&dcsuri=/Our-Services/Our-Services/&dcsref=https://www.sgn.co.uk/&WT.tz=0&WT.bh=12&WT.ul=en-US&WT.cd=24&WT.sr=1920x1080&WT.jo=Yes&WT.ti=SGN:%20Your%20gas.%20Our%20network.%20Our-Services&WT.js=Yes&WT.jv=1.5&WT.ct=unknown&WT.bs=1920x929&WT.fv=Not%20enabled&WT.slv=Unknown&WT.tv=9.4.0&WT.dl=0&WT.ssl=1&WT.es=www.sgn.co.uk/Our-Services/Our-Services/&WT.vt_f_a=2&WT.vt_f=2", ENDITEM, 
		LAST);

	lr_think_time(9);

	web_url("01-SGN-Connections", 
		"URL=https://www.sgn.co.uk/Our-Services/01-SGN-Connections/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.sgn.co.uk/Our-Services/Our-Services/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/images/breadcrumb-arrow.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Controls/Site_Logos/scotia_red_blue.jpg", ENDITEM, 
		"Url=/uploadedImages/Marketing/Pages/Our-Services/Our-Services-Images/475x100-SGN-Connections-Logo.png", ENDITEM, 
		"Url=/images/breadcrumb-arrow-end.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Pages/Our-Services/Our-Services-Images/75x75-Factory.png?n=1821", ENDITEM, 
		"Url=/uploadedImages/Marketing/Pages/Our-Services/Our-Services-Images/75x75-House.png?n=9889", ENDITEM, 
		"Url=/uploadedImages/Marketing/Pages/Our-Services/Our-Services-Images/75x75-Flats.png?n=2907", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/1x1-transparency.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Pages/Our-Services/Our-Services-Images/200x264-RHS-Connect.png", ENDITEM, 
		"Url=/images/background.png", ENDITEM, 
		"Url=/images/icon-sprites.png", ENDITEM, 
		"Url=/images/menu-side-bg-arrow.png", ENDITEM, 
		"Url=/images/menu-side-bg.png", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/wtid.js", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/dcs.gif?&dcsdat=1489668989596&dcssip=www.sgn.co.uk&dcsuri=/Our-Services/01-SGN-Connections/&dcsref=https://www.sgn.co.uk/Our-Services/Our-Services/&WT.tz=0&WT.bh=12&WT.ul=en-US&WT.cd=24&WT.sr=1920x1080&WT.jo=Yes&WT.ti=SGN:%20Your%20gas.%20Our%20network.%2001-SGN-Connections&WT.js=Yes&WT.jv=1.5&WT.ct=unknown&WT.bs=1920x929&WT.fv=Not%20enabled&WT.slv=Unknown&WT.tv=9.4.0&WT.dl=0&WT.ssl=1&WT.es=www.sgn.co.uk/Our-Services/"
		"01-SGN-Connections/&WT.vt_f_a=2&WT.vt_f=2", ENDITEM, 
		LAST);

	lr_think_time(12);

	web_url("02-SGN-Connections", 
		"URL=https://www.sgn.co.uk/Our-Services/01-SGN-Connections/02-SGN-Connections/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.sgn.co.uk/Our-Services/01-SGN-Connections/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/uploadedImages/Marketing/Controls/Site_Logos/scotia_red_blue.jpg", ENDITEM, 
		"Url=/images/breadcrumb-arrow.png", ENDITEM, 
		"Url=/images/breadcrumb-arrow-end.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Pages/Our-Services/Our-Services-Images/475x100-SGN-Connections-Logo.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Pages/Our-Services/Our-Services-Images/75x75-Arrow-RT.png?n=2859", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/1x1-transparency.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Pages/Our-Services/Our-Services-Images/200x138-RHS-Connect.png?n=4470", ENDITEM, 
		"Url=/images/background.png", ENDITEM, 
		"Url=/images/icon-sprites.png", ENDITEM, 
		"Url=/images/menu-side-bg.png", ENDITEM, 
		"Url=/images/menu-side-bg-arrow.png", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/wtid.js", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/dcs.gif?&dcsdat=1489669008254&dcssip=www.sgn.co.uk&dcsuri=/Our-Services/01-SGN-Connections/02-SGN-Connections/&dcsref=https://www.sgn.co.uk/Our-Services/01-SGN-Connections/&WT.tz=0&WT.bh=12&WT.ul=en-US&WT.cd=24&WT.sr=1920x1080&WT.jo=Yes&WT.ti=SGN:%20Your%20gas.%20Our%20network.%2002-SGN-Connections&WT.js=Yes&WT.jv=1.5&WT.ct=unknown&WT.bs=1920x929&WT.fv=Not%20enabled&WT.slv=Unknown&WT.tv=9.4.0&WT.dl=0&WT.ssl=1&WT.es=www.sgn.co.uk/"
		"Our-Services/01-SGN-Connections/02-SGN-Connections/&WT.vt_f_a=2&WT.vt_f=2", ENDITEM, 
		LAST);

	web_url("03-SGN-Connections", 
		"URL=https://www.sgn.co.uk/Our-Services/01-SGN-Connections/03-SGN-Connections/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.sgn.co.uk/Our-Services/01-SGN-Connections/02-SGN-Connections/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/1x1-transparency.png", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/wtid.js", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/dcs.gif?&dcsdat=1489669014825&dcssip=www.sgn.co.uk&dcsuri=/Our-Services/01-SGN-Connections/03-SGN-Connections/&dcsref=https://www.sgn.co.uk/Our-Services/01-SGN-Connections/02-SGN-Connections/&WT.tz=0&WT.bh=12&WT.ul=en-US&WT.cd=24&WT.sr=1920x1080&WT.jo=Yes&WT.ti=SGN:%20Your%20gas.%20Our%20network.%2003-SGN-Connections&WT.js=Yes&WT.jv=1.5&WT.ct=unknown&WT.bs=1920x929&WT.fv=Not%20enabled&WT.slv=Unknown&WT.tv=9.4.0&WT.dl=0&WT.ssl=1&"
		"WT.es=www.sgn.co.uk/Our-Services/01-SGN-Connections/03-SGN-Connections/&WT.vt_f_a=2&WT.vt_f=2", ENDITEM, 
		LAST);

	web_url("SignIn", 
		"URL=https://www.sgn.co.uk/services/SignIn", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.sgn.co.uk/Our-Services/01-SGN-Connections/03-SGN-Connections/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=cassette.axd/file/images/background-68d1db0dbe60499455a17be8629b72bd2c150c1b.png", ENDITEM, 
		"Url=cassette.axd/file/images/icon-sprites-80f643edb5cdf650e7ca527f0ec26a9f5efdf652.png", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/wtid.js", ENDITEM, 
		"Url=images/Open-eye.png", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/dcs.gif?&dcsdat=1489669028929&dcssip=www.sgn.co.uk&dcsuri=/services/SignIn&dcsref=https://www.sgn.co.uk/Our-Services/01-SGN-Connections/03-SGN-Connections/&WT.tz=0&WT.bh=12&WT.ul=en-US&WT.cd=24&WT.sr=1920x1080&WT.jo=Yes&WT.ti=SGN%20Sign%20In&WT.js=Yes&WT.jv=1.5&WT.ct=unknown&WT.bs=1920x929&WT.fv=Not%20enabled&WT.slv=Unknown&WT.tv=9.4.0&WT.dl=0&WT.ssl=1&WT.es=www.sgn.co.uk/services/SignIn&WT.vt_f_a=2&WT.vt_f=2", ENDITEM, 
		LAST);

	lr_think_time(5);

	web_image("SGN Logo", 
		"Alt=SGN Logo", 
		"Snapshot=t7.inf", 
		EXTRARES, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/1x1-transparency.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Controls/Site_Logos/scotia_red_blue.jpg", ENDITEM, 
		"Url=/uploadedFiles/Marketing/Controls/Rotating-Banners/CAROUSEL-170314.js", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Emergency-Trio.jpg", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Connect.jpg", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/270x60-Our-Latest-News.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Upgrade.jpg", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Vacancies.jpg", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/270x93-Button-More-SGN-News.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Dead-Or-Alive.png?n=6745", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Recognise.jpg", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/270x60-SGN-Who-Are-We.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-SGN-Alert.png?n=6446", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Vulnerable-Customers.png?n=3454", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/270x93-Button-About-Us.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x60-Contact-Us.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x106-Customer-Service-Smell-Gas-Transparency.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x58-Twitter-Transparency.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x48-Facebook-Transparency.png", ENDITEM, 
		"Url=/images/background.png", ENDITEM, 
		"Url=/images/icon-sprites.png", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/wtid.js", ENDITEM, 
		"Url=/uploadedImages/Marketing/Controls/Rotating-Banners/170303-co-monster-compettion-v2.gif", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/dcs.gif?&dcsdat=1489669034143&dcssip=www.sgn.co.uk&dcsuri=/&dcsref=https://www.sgn.co.uk/services/SignIn&WT.tz=0&WT.bh=12&WT.ul=en-US&WT.cd=24&WT.sr=1920x1080&WT.jo=Yes&WT.ti=SGN:%20Your%20gas.%20Our%20network.%20Home&WT.js=Yes&WT.jv=1.5&WT.ct=unknown&WT.bs=1920x929&WT.fv=Not%20enabled&WT.slv=Unknown&WT.tv=9.4.0&WT.dl=0&WT.ssl=1&WT.es=www.sgn.co.uk/&WT.vt_f_a=2&WT.vt_f=2", ENDITEM, 
		LAST);

	return 0;
}