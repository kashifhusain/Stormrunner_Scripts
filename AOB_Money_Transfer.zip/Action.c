//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("1", "Navigate to 'http://15.126.221.115:47001/advantage/'", "snapshot=Action_1.inf");
	lr_start_transaction("AOB Login");
	truclient_step("2", "Login", "snapshot=Action_2.inf");
	{
		truclient_step("2.1", "Click on User ID textbox", "snapshot=Action_2.1.inf");
		truclient_step("2.2", "Type jojo in User ID textbox", "snapshot=Action_2.2.inf");
		truclient_step("2.3", "Click on Password passwordbox", "snapshot=Action_2.3.inf");
		truclient_step("2.4", "Type ************ in Password passwordbox", "snapshot=Action_2.4.inf");
		truclient_step("2.5", "Click on Login button", "snapshot=Action_2.5.inf");
	}
	lr_end_transaction("AOB Login",0);
	truclient_step("3", "Click on Money Transfer link", "snapshot=Action_3.inf");
	truclient_step("4", "Select option #6 from From account listbox", "snapshot=Action_4.inf");
	truclient_step("5", "Select option #2 from To account listbox", "snapshot=Action_5.inf");
	truclient_step("6", "Click on Next button", "snapshot=Action_6.inf");
	truclient_step("7", "Click on Amount textbox", "snapshot=Action_7.inf");
	truclient_step("8", "Type 1 in Amount textbox", "snapshot=Action_8.inf");
	truclient_step("9", "Click on Date textbox", "snapshot=Action_9.inf");
	truclient_step("12", "Next", "snapshot=Action_12.inf");
	{
		truclient_step("12.1", "Click on Date textbox", "snapshot=Action_12.1.inf");
		truclient_step("12.2", "Type 12/31/2015 in Date textbox", "snapshot=Action_12.2.inf");
		truclient_step("12.3", "Click on Next button", "snapshot=Action_12.3.inf");
	}
	lr_start_transaction("AOB Money Transfer");
	truclient_step("13", "Click on OK button", "snapshot=Action_13.inf");
	truclient_step("14", "Verify The following transfer... 's 'Visible Text' Contain The following transfer has been made:", "snapshot=Action_14.inf");
	lr_end_transaction("AOB Money Transfer",0);
	truclient_step("15", "Click on Logout link", "snapshot=Action_15.inf");

	return 0;
}
