//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("1", "Navigate to 'advantageonlineshopping.com'", "snapshot=Action_1.inf");
	lr_start_transaction("Speakers");
	truclient_step("2", "Click on SPEAKERS Shop Now", "snapshot=Action_2.inf");
	truclient_step("3", "Click on HOME link", "snapshot=Action_3.inf");
	lr_end_transaction("Speakers",0);
	lr_start_transaction("Tablet");
	truclient_step("4", "Click on TABLETS", "snapshot=Action_4.inf");
	truclient_step("5", "Click on HOME link", "snapshot=Action_5.inf");
	lr_end_transaction("Tablet",0);
	lr_start_transaction("Headphones");
	truclient_step("6", "Click on HEADPHONES Shop Now", "snapshot=Action_6.inf");
	lr_end_transaction("Headphones",0);
	truclient_step("7", "Click on HOME link", "snapshot=Action_7.inf");
	lr_start_transaction("Mice");
	truclient_step("8", "Click on MICE Shop Now", "snapshot=Action_8.inf");
	lr_end_transaction("Mice",0);
	truclient_step("9", "Click on HOME link", "snapshot=Action_9.inf");

	return 0;
}
