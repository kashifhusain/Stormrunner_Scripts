//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("2", "Navigate to 'http://www.bbc.co.uk/sport/0/'", "snapshot=Action_2.inf");
	lr_start_transaction("Transaction 3");
	truclient_step("3", "Click on Football link", "snapshot=Action_3.inf");
	lr_end_transaction("Transaction 3",0);
	lr_start_transaction("Transaction 4");
	truclient_step("5", "Click on Tables link", "snapshot=Action_5.inf");
	lr_end_transaction("Transaction 4",0);
	truclient_step("7", "Click on Home link", "snapshot=Action_7.inf");

	return 0;
}
