//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("1", "Navigate to 'http://www.altoromutual.com/'", "snapshot=Action_1.inf");
	truclient_step("2", "Click on Sign In link", "snapshot=Action_2.inf");
	truclient_step("3", "Login", "snapshot=Action_3.inf");
	{
		truclient_step("3.1", "Type jsmith in Username textbox", "snapshot=Action_3.1.inf");
		truclient_step("3.2", "Type ******** in Password passwordbox", "snapshot=Action_3.2.inf");
		truclient_step("3.3", "Click on Login button", "snapshot=Action_3.3.inf");
	}
	lr_start_transaction("Card application");
	truclient_step("4", "Click on Here link", "snapshot=Action_4.inf");
	truclient_step("6", "Type ******** in Password passwordbox", "snapshot=Action_6.inf");
	truclient_step("7", "Click on Submit button", "snapshot=Action_7.inf");
	lr_end_transaction("Card application",0);
	truclient_step("8", "Click on Sign Off link", "snapshot=Action_8.inf");

	return 0;
}
