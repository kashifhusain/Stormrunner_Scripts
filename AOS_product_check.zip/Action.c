//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("1", "Navigate to 'http://www.advantageonl...shopping.com/#/'", "snapshot=Action_1.inf");
	lr_start_transaction("Speaker");
	truclient_step("2", "Click on SPEAKERS Shop Now", "snapshot=Action_2.inf");
	truclient_step("4", "Click on image (1) image", "snapshot=Action_4.inf");
	truclient_step("5", "Click on RED", "snapshot=Action_5.inf");
	truclient_step("6", "Click on ADD TO CART button", "snapshot=Action_6.inf");
	lr_end_transaction("Speaker",0);
	truclient_step("7", "Click on HOME link", "snapshot=Action_7.inf");
	lr_start_transaction("Mice");
	truclient_step("8", "Click on MICE Shop Now", "snapshot=Action_8.inf");
	truclient_step("9", "Click on PRICE heading", "snapshot=Action_9.inf");
	truclient_step("10", "Drag element (1) 156px left", "snapshot=Action_10.inf");
	truclient_step("11", "Click on image (2) image", "snapshot=Action_11.inf");
	truclient_step("12", "Click on RED", "snapshot=Action_12.inf");
	truclient_step("13", "Click on WHITE", "snapshot=Action_13.inf");
	truclient_step("15", "Click on GRAY", "snapshot=Action_15.inf");
	truclient_step("17", "Click on ADD TO CART button", "snapshot=Action_17.inf");
	lr_end_transaction("Mice",0);
	truclient_step("18", "Click on HOME link", "snapshot=Action_18.inf");
	lr_start_transaction("Special Offers");
	truclient_step("19", "Click on SPECIAL OFFER ITEMS", "snapshot=Action_19.inf");
	truclient_step("20", "Click on SEE OFFER button", "snapshot=Action_20.inf");
	truclient_step("21", "Click on BLUE", "snapshot=Action_21.inf");
	truclient_step("22", "Click on GRAY", "snapshot=Action_22.inf");
	truclient_step("23", "Click on PURPLE", "snapshot=Action_23.inf");
	truclient_step("24", "Click on RED", "snapshot=Action_24.inf");
	truclient_step("25", "Click on ADD TO CART button", "snapshot=Action_25.inf");
	lr_end_transaction("Special Offers",0);
	truclient_step("26", "Click on CHECKOUT button", "snapshot=Action_26.inf");
	truclient_step("27", "Click on USER", "snapshot=Action_27.inf");
	truclient_step("28", "Click on CloseDark", "snapshot=Action_28.inf");
	truclient_step("29", "Click on HOME link", "snapshot=Action_29.inf");
	truclient_step("30", "Close active tab", "snapshot=Action_30.inf");

	return 0;
}
