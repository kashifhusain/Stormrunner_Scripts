//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	lr_start_transaction("Transaction 11");
	truclient_step("1", "Navigate to 'https://www.sgn.co.uk/'", "snapshot=Action_1.inf");
	lr_end_transaction("Transaction 11",0);
	truclient_step("5", "Click on Contact us link", "snapshot=Action_5.inf");
	lr_start_transaction("Transaction 3");
	truclient_step("6", "Click on Customer Charter link", "snapshot=Action_6.inf");
	lr_end_transaction("Transaction 3",0);
	lr_start_transaction("Transaction 4");
	truclient_step("7", "Click on 10/10 nominations link", "snapshot=Action_7.inf");
	lr_end_transaction("Transaction 4",0);
	lr_start_transaction("Transaction 5");
	truclient_step("9", "Go Back a page", "snapshot=Action_9.inf");
	lr_end_transaction("Transaction 5",0);
	lr_start_transaction("Transaction 6");
	truclient_step("10", "Click on Guaranteed standards link", "snapshot=Action_10.inf");
	lr_end_transaction("Transaction 6",0);
	lr_start_transaction("Transaction 7");
	truclient_step("11", "Click on Complaints link", "snapshot=Action_11.inf");
	lr_end_transaction("Transaction 7",0);
	lr_start_transaction("Transaction 8");
	truclient_step("12", "Click on Compensation link", "snapshot=Action_12.inf");
	lr_end_transaction("Transaction 8",0);
	lr_start_transaction("Transaction 9");
	truclient_step("13", "Click on Procurement link", "snapshot=Action_13.inf");
	lr_end_transaction("Transaction 9",0);
	lr_start_transaction("Transaction 10");
	truclient_step("14", "Click on Plant protection link", "snapshot=Action_14.inf");
	lr_end_transaction("Transaction 10",0);
	truclient_step("15", "Click on About SGN link", "snapshot=Action_15.inf");

	return 0;
}
