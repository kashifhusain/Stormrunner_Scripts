//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	lr_start_transaction("AOB Full Flow");
	truclient_step("1", "Navigate to 'http://131.124.73.104:47001/advantage/'", "snapshot=Action_1.inf");
	truclient_step("2", "Login", "snapshot=Action_2.inf");
	{
		truclient_step("2.2", "Type jojo in User ID textbox", "snapshot=Action_2.2.inf");
		truclient_step("2.3", "Type ************** in Password passwordbox", "snapshot=Action_2.3.inf");
		truclient_step("2.4", "Click on Login button", "snapshot=Action_2.4.inf");
	}
	truclient_step("3", "Wait 3 seconds", "snapshot=Action_3.inf");
	lr_start_transaction("Check Credit Cards");
	truclient_step("4", "Click on Credit Cards link", "snapshot=Action_4.inf");
	truclient_step("6", "Go back a page", "snapshot=Action_6.inf");
	lr_end_transaction("Check Credit Cards",0);
	truclient_step("7", "Wait 3 seconds", "snapshot=Action_7.inf");
	lr_start_transaction("Order Checkbooks");
	truclient_step("8", "Click on Order Checkbooks link", "snapshot=Action_8.inf");
	truclient_step("9", "Add to Cart", "snapshot=Action_9.inf");
	{
		truclient_step("9.1", "Check on checkbox", "snapshot=Action_9.1.inf");
		truclient_step("9.3", "Type '2' in TextBox textbox", "snapshot=Action_9.3.inf");
		truclient_step("9.4", "Click on Add to Cart button", "snapshot=Action_9.4.inf");
	}
	truclient_step("10", "Click on Check Out button", "snapshot=Action_10.inf");
	truclient_step("11", "Press OK in alert dialog", "snapshot=Action_11.inf");
	lr_end_transaction("AOB Full Flow",0);
	lr_end_transaction("Order Checkbooks",0);
	truclient_step("12", "Wait 3 seconds", "snapshot=Action_12.inf");

	return 0;
}
