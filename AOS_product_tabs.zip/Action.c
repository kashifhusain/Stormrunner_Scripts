//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("1", "Navigate to 'http://advantageonlineshopping.com/'", "snapshot=Action_1.inf");
	lr_start_transaction("Transaction 1");
	lr_start_transaction("Transaction 5");
	truclient_step("2", "Click on OUR PRODUCTS", "snapshot=Action_2.inf");
	lr_end_transaction("Transaction 1",0);
	lr_end_transaction("Transaction 5",0);
	lr_start_transaction("Transaction 2");
	truclient_step("3", "Click on SPEAKERS", "snapshot=Action_3.inf");
	lr_end_transaction("Transaction 2",0);
	truclient_step("4", "Click on HOME link", "snapshot=Action_4.inf");
	lr_start_transaction("Transaction 3");
	truclient_step("5", "Click on TABLETS", "snapshot=Action_5.inf");
	lr_end_transaction("Transaction 3",0);
	truclient_step("6", "Click on HOME link", "snapshot=Action_6.inf");
	lr_start_transaction("Transaction 4");
	truclient_step("7", "Click on HEADPHONES Shop Now", "snapshot=Action_7.inf");
	lr_end_transaction("Transaction 4",0);
	truclient_step("8", "Click on HOME link", "snapshot=Action_8.inf");

	return 0;
}
