//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

vuser_init()
{
	return 0;
}

Action()
{
	lr_start_transaction("Transaction 3");
	truclient_step("1", "Tap on com.Advantage.aShopping:id/imageViewMenu View", "snapshot=Action_1.inf");
	lr_end_transaction("Transaction 3",0);
	lr_start_transaction("Transaction 6");
	truclient_step("2", "Tap on LOGIN Label", "snapshot=Action_2.inf");
	lr_end_transaction("Transaction 6",0);
	truclient_step("3", "Type kashif", "snapshot=Action_3.inf");
	truclient_step("4", "Tap on PASSWORD Label", "snapshot=Action_4.inf");
	truclient_step("5", "Type Kashif74", "snapshot=Action_5.inf");
	lr_start_transaction("Transaction 4");
	truclient_step("6", "Tap on LOGIN Button", "snapshot=Action_6.inf");
	lr_end_transaction("Transaction 4",0);
	truclient_step("7", "Tap on com.Advantage.aShopping:id/imageViewMenu View", "snapshot=Action_7.inf");
	lr_start_transaction("Transaction 5");
	truclient_step("8", "Tap on SIGN OUT Label", "snapshot=Action_8.inf");
	lr_end_transaction("Transaction 5",0);
	truclient_step("9", "Tap on YES Button", "snapshot=Action_9.inf");

	return 0;
}

vuser_end()
{
	return 0;
}
