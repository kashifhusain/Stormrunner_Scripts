//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	lr_start_transaction("Transaction 1");
	truclient_step("1", "Navigate to 'http://sgn.co.uk/'", "snapshot=Action_1.inf");
	lr_end_transaction("Transaction 1",0);
	lr_start_transaction("Transaction 2");
	truclient_step("2", "Click on Search textbox", "snapshot=Action_2.inf");
	lr_end_transaction("Transaction 2",0);
	truclient_step("3", "Click on Search textbox", "snapshot=Action_3.inf");
	truclient_step("4", "Type Search_Word in Search textbox", "snapshot=Action_4.inf");
	lr_start_transaction("Transaction 4");
	truclient_step("5", "Click on javascript_link (1) javascript_link", "snapshot=Action_5.inf");
	lr_end_transaction("Transaction 4",0);
	lr_start_transaction("Transaction 3");
	truclient_step("6", "Click on logo image", "snapshot=Action_6.inf");
	lr_end_transaction("Transaction 3",0);

	return 0;
}
