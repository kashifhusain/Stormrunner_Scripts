Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	lr_start_transaction("1_transaction");

	web_add_cookie("EkAnalytics=0; DOMAIN=www.sgn.co.uk");

	web_add_cookie("EktGUID=9dd3717a-9a5a-4633-9ed8-da417734a302; DOMAIN=www.sgn.co.uk");

	web_add_cookie("ACOOKIE=C8ctADRmODBjMDJkLTllM2UtNDY4Zi04ODliLWU1YmRkZjM0YmEwNgAAAAABAAAASzEBANebyligm8pYAQAAAOVVAADXm8pYoJvKWAAAAAA-; DOMAIN=statse.webtrendslive.com");

	web_url("www.sgn.co.uk", 
		"URL=http://www.sgn.co.uk/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.sgn.co.uk/WebResource.axd?d=aOgP67iRH9VtGEflBarWk5DJ4Ww0rkp72uGffVwNaHaHCs5WALA-ZI1h9lwAW8WfgCR9iOc9LnTgU3EoihFp4iGlGUg1&t=635802997220000000", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/ScriptResource.axd?d=XJ91eqeOWdbvfgIM0ICGQ9czP5_d0UNrti8d4tkfF4KvhbYzpI9k3e6bKXppVHW_jVrYI1fPHUYR7pizwJJ0KaylL4-mHqV8YdWpIANNwVyC7rhqozQM8Q0p3UbCM8nutxkxbj8wsP_LwZV4B607QVcLhgCKeQ5c0fvKp3bCbrrJOMBa0&t=5f9d5645", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/ScriptResource.axd?d=K2g_57wYEFmw9E-IG-f4eUIZOpTPMhV7r26g4uROvCI4PYjHdrKhzL9O_9AiJfnrEEA7kTEzx_bHyzbITC3NNipCk4mv-_HXopCqt5Ujb8Bly6aJQIitNdUokTqgF1QQceS3GQTQPQiITA2JK4Jq55F5POMRittIafkl_iejS60wykJQ0&t=5f9d5645", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedFiles/Marketing/Controls/Rotating-Banners/CAROUSEL-170314.js", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Controls/Site_Logos/scotia_red_blue.jpg", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/1x1-transparency.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Connect.jpg", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Emergency-Trio.jpg", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Upgrade.jpg", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/270x60-Our-Latest-News.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/270x93-Button-More-SGN-News.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Vacancies.jpg", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Recognise.jpg", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-SGN-Alert.png?n=6446", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/Annual-report-button.jpg", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Vulnerable-Customers.png?n=3454", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Dead-Or-Alive.png?n=6745", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/270x60-SGN-Who-Are-We.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/270x93-Button-About-Us.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x60-Contact-Us.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x106-Customer-Service-Smell-Gas-Transparency.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x58-Twitter-Transparency.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x48-Facebook-Transparency.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/images/background.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/images/icon-sprites.png", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/wtid.js", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/dcs.gif?&dcsdat=1489673267693&dcssip=www.sgn.co.uk&dcsuri=/&WT.tz=0&WT.bh=14&WT.ul=en-US&WT.cd=24&WT.sr=1920x1080&WT.jo=Yes&WT.ti=SGN:%20Your%20gas.%20Our%20network.%20Home&WT.js=Yes&WT.jv=1.5&WT.ct=unknown&WT.bs=1920x929&WT.fv=Not%20enabled&WT.slv=Unknown&WT.tv=9.4.0&WT.dl=0&WT.ssl=1&WT.es=www.sgn.co.uk/&WT.vt_f_a=2&WT.vt_f=2", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		"Url=https://www.sgn.co.uk/uploadedImages/Marketing/Controls/Rotating-Banners/170303-co-monster-compettion-v2.gif", "Referer=https://www.sgn.co.uk/", ENDITEM, 
		LAST);

	lr_end_transaction("1_transaction",LR_AUTO);

	lr_start_transaction("2_transaction");

	web_reg_find("Text=Yes, this postcode is within our operating regions", 
		LAST);

	lr_think_time(24);

	web_url("Our-Services", 
		"URL=https://www.sgn.co.uk/Our-Services/Our-Services/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.sgn.co.uk/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/images/breadcrumb-arrow.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Controls/Site_Logos/scotia_red_blue.jpg", ENDITEM, 
		"Url=/images/breadcrumb-arrow-end.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Pages/Our-Services/Our-Services-Images/200x338-RHS-Connect.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/1x1-transparency.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Pages/Our-Services/Our-Services-Images/connections-our-services-475px-200px.jpg?n=4929", ENDITEM, 
		"Url=/images/background.png", ENDITEM, 
		"Url=/images/menu-side-bg.png", ENDITEM, 
		"Url=/images/menu-side-bg-arrow.png", ENDITEM, 
		"Url=/images/icon-sprites.png", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/wtid.js", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/dcs.gif?&dcsdat=1489673294741&dcssip=www.sgn.co.uk&dcsuri=/Our-Services/Our-Services/&dcsref=https://www.sgn.co.uk/&WT.tz=0&WT.bh=14&WT.ul=en-US&WT.cd=24&WT.sr=1920x1080&WT.jo=Yes&WT.ti=SGN:%20Your%20gas.%20Our%20network.%20Our-Services&WT.js=Yes&WT.jv=1.5&WT.ct=unknown&WT.bs=1920x929&WT.fv=Not%20enabled&WT.slv=Unknown&WT.tv=9.4.0&WT.dl=0&WT.ssl=1&WT.es=www.sgn.co.uk/Our-Services/Our-Services/&WT.vt_f_a=2&WT.vt_f=2", ENDITEM, 
		"Url=/services/Query?query.name=SgnRegionCheck.BySgnPostcodeQuery&query.values=%7B%22postcode%22%3A%22kt33jy%22%7D", ENDITEM, 
		LAST);

	lr_end_transaction("2_transaction",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("3_transaction");

	lr_end_transaction("3_transaction",LR_AUTO);

	web_url("www.sgn.co.uk_2", 
		"URL=https://www.sgn.co.uk/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.sgn.co.uk/Our-Services/Our-Services/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/uploadedImages/Marketing/Controls/Site_Logos/scotia_red_blue.jpg", ENDITEM, 
		"Url=/uploadedFiles/Marketing/Controls/Rotating-Banners/CAROUSEL-170314.js", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/1x1-transparency.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Emergency-Trio.jpg", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Connect.jpg", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Upgrade.jpg", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/270x60-Our-Latest-News.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/270x93-Button-More-SGN-News.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Vacancies.jpg", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Recognise.jpg", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Dead-Or-Alive.png?n=6745", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-SGN-Alert.png?n=6446", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/270x60-SGN-Who-Are-We.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x220-Vulnerable-Customers.png?n=3454", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x60-Contact-Us.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/270x93-Button-About-Us.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x106-Customer-Service-Smell-Gas-Transparency.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x58-Twitter-Transparency.png", ENDITEM, 
		"Url=/uploadedImages/Marketing/Content/Homepage/Homepage_images/310x48-Facebook-Transparency.png", ENDITEM, 
		"Url=/images/background.png", ENDITEM, 
		"Url=/images/icon-sprites.png", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/wtid.js", ENDITEM, 
		"Url=/uploadedImages/Marketing/Controls/Rotating-Banners/170303-co-monster-compettion-v2.gif", ENDITEM, 
		"Url=https://statse.webtrendslive.com/dcsupmpjuuz5bdbjy1gotl2ld_6l9d/dcs.gif?&dcsdat=1489673344522&dcssip=www.sgn.co.uk&dcsuri=/&dcsref=https://www.sgn.co.uk/Our-Services/Our-Services/&WT.tz=0&WT.bh=14&WT.ul=en-US&WT.cd=24&WT.sr=1920x1080&WT.jo=Yes&WT.ti=SGN:%20Your%20gas.%20Our%20network.%20Home&WT.js=Yes&WT.jv=1.5&WT.ct=unknown&WT.bs=1920x929&WT.fv=Not%20enabled&WT.slv=Unknown&WT.tv=9.4.0&WT.dl=0&WT.ssl=1&WT.es=www.sgn.co.uk/&WT.vt_f_a=2&WT.vt_f=2", ENDITEM, 
		LAST);

	return 0;
}