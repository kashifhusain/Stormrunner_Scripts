//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	lr_start_transaction("Transaction 1");
	truclient_step("1", "Navigate to 'http://store.hp.com/UKStore/Default.aspx'", "snapshot=Action_1.inf");
	lr_end_transaction("Transaction 1",0);
	lr_start_transaction("Transaction 2");
	truclient_step("3", "Click on Laptops link", "snapshot=Action_3.inf");
	lr_end_transaction("Transaction 2",0);
	lr_start_transaction("Transaction 3");
	truclient_step("6", "Click on On/Off", "snapshot=Action_6.inf");
	lr_end_transaction("Transaction 3",0);
	lr_start_transaction("Transaction 4");
	truclient_step("7", "Click on element (1)", "snapshot=Action_7.inf");
	lr_end_transaction("Transaction 4",0);
	lr_start_transaction("Transaction 5");
	truclient_step("9", "Click on element (2)", "snapshot=Action_9.inf");
	lr_end_transaction("Transaction 5",0);
	lr_start_transaction("Transaction 6");
	truclient_step("11", "Click on element (4)", "snapshot=Action_11.inf");
	lr_end_transaction("Transaction 6",0);
	lr_start_transaction("Transaction 7");
	truclient_step("13", "Click on element (5)", "snapshot=Action_13.inf");
	lr_end_transaction("Transaction 7",0);
	lr_start_transaction("Transaction 8");
	truclient_step("15", "Click on button (1) button", "snapshot=Action_15.inf");
	lr_end_transaction("Transaction 8",0);
	lr_start_transaction("Transaction 9");
	truclient_step("17", "Click on Continue Shopping button", "snapshot=Action_17.inf");
	lr_end_transaction("Transaction 9",0);
	lr_start_transaction("Transaction 10");
	truclient_step("19", "Click on Hewlett Packard link", "snapshot=Action_19.inf");
	lr_end_transaction("Transaction 10",0);
	truclient_step("21", "Click on Continue button", "snapshot=Action_21.inf");

	return 0;
}
